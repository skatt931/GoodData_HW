export const MAIN_PAGE = {
  // For each month we can create object with months name and key number
  MONTHS_NAMES: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
  ALIAS: '$ Gross Profit',
  FIRST_CHART_TITLE: '$ Gross Profit in month',
  SECOND_CHART_TITLE: '$ Gross Profit - All months',
}